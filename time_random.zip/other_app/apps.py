from django.apps import AppConfig


class OtherAppConfig(AppConfig):
    name = 'other_app'
